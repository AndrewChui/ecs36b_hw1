// Name: Kwok Chui
// Student ID: [923 216 256]
// ECS36B - Homework 1 problem 2
// declaration
#include "Fraction.h"
#include <iostream>
#include <stdexcept>
using namespace std;

// helper function
int gcd(int a, int b);

// section 1: constructors
// Default constructor
Fraction::Fraction() // this function belongs to the fraction class
{
	num = 0;
	denom = 1;
}

// other constructors
Fraction::Fraction(int a)
{
	num = a; // we want to represent a whole number as a fraction
	denom = 1;
}

Fraction::Fraction(int a, int b)
{
	if (b == 0)
		throw invalid_argument("Exception: zero denominator");
	num = a;
	denom = b;
	// return it in reduced form using GCD
	int g = gcd(num, denom);
	num /= g;
	denom /= g;

	// make sure denominator is not 0
	if (denom < 0)
	{
		num *= -1;
		denom *= -1;
	}

}

Fraction::Fraction(const Fraction &x) // copy constructor, Fraction& means "a reference to a Fraction object"
{
	num = x.num;
	denom = x.denom;
}

Fraction &Fraction::operator=(const Fraction &rhs) // assignment operator, rhs means right-hand side
{
	if (&rhs == this)
		return *this;
	// insert copy operations here
	// copy elements of rhs onto *this
	(*this).num = rhs.num;
	(*this).denom = rhs.denom;
	return *this;
}

// section 2 :accessor functions
int Fraction::getNum() const // accessor for the num variable
{
	return num;
}

int Fraction::getDen() const
{
	return denom;
}

// section 3: gcd helper function
int gcd(int a, int b)
{
	int bigNum = abs(a);
	int smallNum = abs(b);
	if (bigNum < smallNum)
	{
		int temp = bigNum;
		bigNum = smallNum;
		smallNum = temp;
	}
	// 1. find the gcd by keep dividing the smaller number by bigger number until the remainder is 0
	while (smallNum != 0)
	{
		int remainder = bigNum % smallNum;
		bigNum = smallNum;
		smallNum = remainder;
		// 1. Divide the bigger number by smaller number to get the remainder
		// int remainder = bigNum % smallNum;
		// 2. if the remainder is not 0, smaller number
		// if(remainder != 0){
		//   bigNum = smallNum;
		//   smallNum = remainder;
		// }
		// else{
		//   gcd = smallNum;
		// }
		// 3. return final gcd
	}
	return bigNum;
}

// section 4:arithmetic operator overloads //teaching the compiler how to add two fraction objects
const Fraction operator+(const Fraction &a, const Fraction &b)
{
	// create an object(new fraction?) inside the function
	// Fraction final_fraction;

	// fill in its data(numerator and denominator
	int final_num = a.getNum() * b.getDen() + b.getNum() * a.getDen();
	int final_denom = a.getDen() * b.getDen();

	// // return it in reduced form using GCD
	// int g = gcd(final_num, final_denom);
	// final_num /= g;
	// final_denom /= g;

	// // make sure denominator is not 0
	// if (final_denom < 0)
	// {
	// 	final_num *= -1;
	// 	final_denom *= -1;
	// }

	// return final fraction
	Fraction final_fraction(final_num, final_denom);

	return final_fraction;
}

const Fraction operator-(const Fraction &a, const Fraction &b) // takes two fractions and returns their difference
{
	// same stuff as operator+ except this is subtraction
	// Fraction final_fraction;

	// fill in its data(numerator and denominator
	// final_fraction.num = a.getNum() * b.getDen() - b.getNum() * a.getDen();
	// final_fraction.denom = a.getDen() * b.getNum();
	int final_num = a.getNum() * b.getDen() - b.getNum() * a.getDen();
	int final_denom = a.getDen() * b.getNum();
	// // return it in reduced form using GCD
	// int g = gcd(final_num, final_denom);
	// final_num /= g;
	// final_denom /= g;

	// // make sure denominator is not 0
	// if (final_denom < 0)
	// {
	// 	final_num *= -1;
	// 	final_denom *= -1;
	// }

	// return final fraction
	Fraction final_fraction(final_num, final_denom);
	return final_fraction;
}

const Fraction operator-(const Fraction &a)
{
	// fill in its data
	int final_num = (-1) * a.getNum();
	int final_denom = a.getDen();

	// // return it in reduced form using GCD
	// int g = gcd(final_num, final_denom);
	// final_num /= g;
	// final_denom /= g;

	// // make sure denominator is not 0
	// if (final_denom < 0)
	// {
	// 	final_num *= -1;
	// 	final_denom *= -1;
	// }

	// return final fraction
	Fraction final_fraction(final_num, final_denom);
	return final_fraction;
}

const Fraction operator*(const Fraction &a, const Fraction &b)
{
	// fill in its data(numerator and denominator
	int final_num = a.getNum() * b.getNum();
	int final_denom = a.getDen() * b.getDen();
	// return it in reduced form using GCD
	// int g = gcd(final_num, final_denom);
	// final_num /= g;
	// final_denom /= g;

	// // make sure denominator is not 0
	// if (final_denom < 0)
	// {
	// 	final_num *= -1;
	// 	final_denom *= -1;
	// }

	// return final fraction
	Fraction final_fraction(final_num, final_denom);
	return final_fraction;
}

const Fraction operator/(const Fraction &a, const Fraction &b)
{

	if (b.getNum() == 0)
	{
		throw invalid_argument("Exception: zero denominator");
	}
	// fill in the data
	int final_num = a.getNum() * b.getDen();
	int final_denom = a.getDen() * b.getNum();

	// // return it in reduced form
	// int g = gcd(final_num, final_denom);
	// final_num /= g;
	// final_denom /= g;

	// // make sure denominator is not 0
	// if (final_denom < 0)
	// {
	// 	final_num *= -1;
	// 	final_denom *= -1;
	// }

	// return final fraction
	Fraction final_fraction(final_num, final_denom);
	return final_fraction;
}

#include "Fraction.h"
#include <iostream>
using namespace std;

ostream &operator<<(ostream &os, const Fraction &x)
{
	// Print like "3/4"
	os << x.num << "/" << x.denom;
	return os; // Always return os for chaining (cout << a << b)
}
